<?php
/**
 * Template Name: About Page
 *
 * @package TeslaFolio
 */

get_header();
?>

<section class="hero" style="min-height: 50vh;">
    <div class="hero-bg">
        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <h1>About <span class="text-red">Us</span></h1>
        <p>Learn more about our mission, vision, and the team behind TeslaFolio.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="about-grid">
            <div class="about-content">
                <h2>Our <span class="text-red">Story</span></h2>
                <p>TeslaFolio was founded with a singular vision: to bridge the gap between cutting-edge technology and everyday users. We believe that the future of innovation should be accessible to everyone.</p>
                <p>Our team consists of passionate technologists, designers, and visionaries who are committed to pushing the boundaries of what's possible. From autonomous vehicles to sustainable energy solutions, we're at the forefront of technological advancement.</p>
                <p>Through our exclusive rewards program, we're not just building products - we're building a community of forward-thinkers who share our vision for a better tomorrow.</p>
            </div>
            <div class="about-image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/about-story.jpg" alt="Our Story">
            </div>
        </div>
    </div>
</section>

<section class="section section-dark">
    <div class="container">
        <h2 class="section-title">Our <span>Values</span></h2>
        <div class="grid grid-3">
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
                    </svg>
                </div>
                <h4>Innovation</h4>
                <p class="text-muted">Constantly pushing the boundaries of technology to create solutions that matter.</p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 6v6l4 2"></path>
                    </svg>
                </div>
                <h4>Sustainability</h4>
                <p class="text-muted">Building a future that's environmentally conscious and energy efficient.</p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <h4>Community</h4>
                <p class="text-muted">Fostering a global community of innovators and early adopters.</p>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="about-grid" style="flex-direction: row-reverse;">
            <div class="about-image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/vision.jpg" alt="Our Vision">
            </div>
            <div class="about-content">
                <h2>Our <span class="text-red">Vision</span></h2>
                <p>We envision a world where technology serves humanity, not the other way around. A future where sustainable energy powers everything, where autonomous vehicles make roads safer, and where innovation creates opportunities for all.</p>
                <p>Through our BNB rewards program, we're giving back to our community and inviting everyone to be part of this technological revolution.</p>
                <a href="<?php echo esc_url(teslafolio_whatsapp_link()); ?>" class="btn btn-red" target="_blank" rel="noopener noreferrer">
                    Join Our Community
                </a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
