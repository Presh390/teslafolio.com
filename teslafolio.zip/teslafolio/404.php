<?php
/**
 * 404 Error Page Template
 *
 * @package TeslaFolio
 */

get_header();
?>

<section class="hero" style="min-height: 100vh;">
    <div class="hero-bg">
        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <h1>404</h1>
        <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Page Not Found</h2>
        <p>The page you're looking for doesn't exist or has been moved.</p>
        <div class="hero-buttons">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">
                Go Home
            </a>
            <a href="<?php echo esc_url(teslafolio_whatsapp_link()); ?>" class="btn btn-outline" target="_blank" rel="noopener noreferrer">
                Contact Us
            </a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
