<?php
/**
 * Template Name: Contact Page
 *
 * @package TeslaFolio
 */

get_header();
?>

<section class="hero" style="min-height: 50vh;">
    <div class="hero-bg">
        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <h1>Contact <span class="text-red">Us</span></h1>
        <p>Get in touch with our team. We're here to help.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="contact-grid">
            <div class="contact-info">
                <h3>Get In Touch</h3>
                <p>Have questions about our projects or rewards program? Reach out to us through any of the channels below.</p>
                
                <div class="contact-item">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                    </div>
                    <div>
                        <strong>WhatsApp</strong>
                        <p style="margin: 0;"><a href="<?php echo esc_url(teslafolio_whatsapp_link()); ?>" target="_blank" rel="noopener noreferrer">+1 (945) 342-2063</a></p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                    </div>
                    <div>
                        <strong>Email</strong>
                        <p style="margin: 0;"><a href="mailto:<?php echo esc_attr(teslafolio_get_option('contact_email', 'contact@teslafolio.com')); ?>"><?php echo esc_html(teslafolio_get_option('contact_email', 'contact@teslafolio.com')); ?></a></p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M12 6v6l4 2"></path>
                        </svg>
                    </div>
                    <div>
                        <strong>Response Time</strong>
                        <p style="margin: 0;">Within 24 hours</p>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="<?php echo esc_url(teslafolio_whatsapp_link("Hello, I have a question about TeslaFolio")); ?>" class="btn btn-red" target="_blank" rel="noopener noreferrer">
                        Chat on WhatsApp
                    </a>
                </div>
            </div>
            
            <div class="contact-form">
                <h3 style="margin-bottom: 1.5rem;">Send a Message</h3>
                <form action="#" method="post">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" required placeholder="Your name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required placeholder="your@email.com">
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" required placeholder="How can we help?">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" required placeholder="Your message..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<section class="section section-dark">
    <div class="container">
        <div class="rewards-card">
            <h3>Ready to Claim Your Rewards?</h3>
            <p class="text-muted" style="max-width: 500px; margin: 0 auto 2rem;">Connect with us on WhatsApp and share your BNB wallet address to receive your exclusive rewards.</p>
            <a href="<?php echo esc_url(teslafolio_whatsapp_link("I'm interested in the Tesla Giveaway")); ?>" class="btn btn-red" target="_blank" rel="noopener noreferrer">
                Claim Your Reward Now
            </a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
