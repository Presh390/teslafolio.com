<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="header-inner">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
            <?php if (has_custom_logo()): ?>
                <?php the_custom_logo(); ?>
            <?php else: ?>
                TESLA<span>FOLIO</span>
            <?php endif; ?>
        </a>
        
        <button class="mobile-menu-toggle" aria-label="Toggle Menu" id="mobile-menu-toggle">
            <span></span>
            <span></span>
            <span></span>
        </button>
        
        <nav class="main-nav" id="main-nav">
            <?php if (has_nav_menu('primary')): ?>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav-menu',
                    'container'      => false,
                    'items_wrap'     => '<ul class="%2$s">%3$s</ul>',
                    'walker'         => new TeslaFolio_Nav_Walker(),
                ));
                ?>
            <?php else: ?>
                <ul class="nav-menu">
                    <li><a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'current' : ''; ?>">Home</a></li>
                    <li><a href="<?php echo esc_url(home_url('/about/')); ?>" class="<?php echo is_page('about') ? 'current' : ''; ?>">About</a></li>
                    <li><a href="<?php echo esc_url(home_url('/projects/')); ?>" class="<?php echo is_page('projects') ? 'current' : ''; ?>">Projects</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact/')); ?>" class="<?php echo is_page('contact') ? 'current' : ''; ?>">Contact</a></li>
                </ul>
            <?php endif; ?>
            <a href="<?php echo esc_url(teslafolio_whatsapp_link("I'm interested in the Tesla Giveaway")); ?>" class="btn btn-red nav-cta" target="_blank" rel="noopener noreferrer">
                Claim Reward
            </a>
        </nav>
    </div>
</header>

<main id="main-content">
