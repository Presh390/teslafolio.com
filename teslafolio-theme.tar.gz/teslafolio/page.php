<?php
/**
 * Default Page Template
 *
 * @package TeslaFolio
 */

get_header();
?>

<section class="hero" style="min-height: 40vh;">
    <div class="hero-bg">
        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <h1><?php the_title(); ?></h1>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php while (have_posts()) : the_post(); ?>
            <article <?php post_class(); ?>>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
</section>

<?php get_footer(); ?>
