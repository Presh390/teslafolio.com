<?php
/**
 * Main Template File
 *
 * @package TeslaFolio
 */

get_header();
?>

<!-- Hero Section -->
<section class="hero" id="home">
    <div class="hero-bg">
        <?php 
        $hero_image = teslafolio_get_option('hero_image');
        if ($hero_image): 
        ?>
            <img src="<?php echo esc_url($hero_image); ?>" alt="Hero Background">
        <?php else: ?>
            <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <?php endif; ?>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <span class="hero-badge animate-fade-in">Exclusive Giveaway</span>
        <h1 class="animate-fade-in animate-delay-1">
            <?php echo esc_html(teslafolio_get_option('hero_title', 'The Future of Innovation')); ?>
        </h1>
        <p class="animate-fade-in animate-delay-2">
            <?php echo esc_html(teslafolio_get_option('hero_subtitle', 'Join us in revolutionizing technology and claim your exclusive BNB rewards. Experience the next generation of digital innovation.')); ?>
        </p>
        <div class="hero-buttons animate-fade-in animate-delay-3">
            <a href="<?php echo esc_url(teslafolio_whatsapp_link("I'm interested in the Tesla Giveaway")); ?>" class="btn btn-primary" target="_blank" rel="noopener noreferrer">
                Claim Your Reward
            </a>
            <a href="#projects" class="btn btn-outline">
                Explore Projects
            </a>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="section" id="stats">
    <div class="container">
        <h2 class="section-title">Our <span>Impact</span></h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                        <path d="M2 17l10 5 10-5"></path>
                        <path d="M2 12l10 5 10-5"></path>
                    </svg>
                </div>
                <div class="stat-value">2.5M+</div>
                <div class="stat-label">Tons CO2 Saved</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M2 12h20"></path>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                    </svg>
                </div>
                <div class="stat-value">15B+</div>
                <div class="stat-label">Miles Driven</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
                    </svg>
                </div>
                <div class="stat-value">50K+</div>
                <div class="stat-label">Superchargers</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <div class="stat-value">200K</div>
                <div class="stat-label">BNB Rewards</div>
            </div>
        </div>
    </div>
</section>

<!-- Projects Section -->
<section class="section section-dark" id="projects">
    <div class="container">
        <h2 class="section-title">Featured <span>Projects</span></h2>
        <div class="grid grid-3">
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-1.jpg" alt="Autonomous Fleet">
                </div>
                <div class="project-content">
                    <h3>Autonomous Fleet</h3>
                    <p>Next-generation self-driving technology powered by neural networks and real-time decision making.</p>
                    <div class="project-tags">
                        <span class="project-tag">AI</span>
                        <span class="project-tag">Automation</span>
                        <span class="project-tag">Safety</span>
                    </div>
                </div>
            </div>
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-2.jpg" alt="Energy Grid">
                </div>
                <div class="project-content">
                    <h3>Energy Grid</h3>
                    <p>Revolutionary sustainable energy infrastructure connecting solar, battery, and grid systems worldwide.</p>
                    <div class="project-tags">
                        <span class="project-tag">Solar</span>
                        <span class="project-tag">Storage</span>
                        <span class="project-tag">Grid</span>
                    </div>
                </div>
            </div>
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-3.jpg" alt="Neural Interface">
                </div>
                <div class="project-content">
                    <h3>Neural Interface</h3>
                    <p>Brain-computer interface technology enabling seamless human-machine communication.</p>
                    <div class="project-tags">
                        <span class="project-tag">Neurotech</span>
                        <span class="project-tag">BCI</span>
                        <span class="project-tag">Medical</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Rewards Section -->
<section class="section" id="rewards">
    <div class="container">
        <h2 class="section-title">Claim Your <span>Rewards</span></h2>
        <div class="rewards-card">
            <h3>Exclusive BNB Giveaway</h3>
            <div class="rewards-amount"><?php echo esc_html(teslafolio_get_option('rewards_amount', '200,000')); ?> BNB</div>
            <p class="text-muted">Join our community and claim your share of the rewards pool</p>
            <div class="rewards-steps">
                <div class="reward-step">
                    <div class="step-number">1</div>
                    <div class="step-text">Connect via WhatsApp</div>
                </div>
                <div class="reward-step">
                    <div class="step-number">2</div>
                    <div class="step-text">Share your BNB wallet address</div>
                </div>
                <div class="reward-step">
                    <div class="step-number">3</div>
                    <div class="step-text">Receive your rewards</div>
                </div>
            </div>
            <a href="<?php echo esc_url(teslafolio_whatsapp_link("I'm interested in the Tesla Giveaway")); ?>" class="btn btn-red" target="_blank" rel="noopener noreferrer">
                Claim Your Reward Now
            </a>
        </div>
    </div>
</section>

<!-- Mission Section -->
<section class="section section-dark" id="mission">
    <div class="container">
        <div class="about-grid">
            <div class="about-content">
                <h2>Our <span class="text-red">Mission</span></h2>
                <p>We are dedicated to accelerating the world's transition to sustainable energy through cutting-edge technology and innovative solutions.</p>
                <p>Our vision is to create a future where clean energy is accessible to everyone, where transportation is autonomous and safe, and where technology empowers humanity to reach new heights.</p>
                <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn btn-outline">
                    Learn More
                </a>
            </div>
            <div class="about-image">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/mission.jpg" alt="Our Mission">
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
