<?php
/**
 * TeslaFolio Theme Functions
 *
 * @package TeslaFolio
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function teslafolio_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-logo', array(
        'height'      => 50,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'teslafolio'),
        'footer'  => __('Footer Menu', 'teslafolio'),
    ));
    
    // Set content width
    if (!isset($content_width)) {
        $content_width = 1280;
    }
}
add_action('after_setup_theme', 'teslafolio_setup');

/**
 * Enqueue Scripts and Styles
 */
function teslafolio_scripts() {
    // Main stylesheet
    wp_enqueue_style('teslafolio-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Google Fonts
    wp_enqueue_style('teslafolio-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@400;500;600;700&display=swap', array(), null);
    
    // Theme JavaScript
    wp_enqueue_script('teslafolio-script', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'teslafolio_scripts');

/**
 * Register Widget Areas
 */
function teslafolio_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget 1', 'teslafolio'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here for the first footer column.', 'teslafolio'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget 2', 'teslafolio'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets here for the second footer column.', 'teslafolio'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'teslafolio_widgets_init');

/**
 * Custom Walker for Navigation Menu
 */
class TeslaFolio_Nav_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        if (in_array('current-menu-item', $classes) || in_array('current_page_item', $classes)) {
            $classes[] = 'current';
        }
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $output .= '<li' . $class_names . '>';
        
        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel']    = !empty($item->xfn) ? $item->xfn : '';
        $atts['href']   = !empty($item->url) ? $item->url : '';
        
        if (in_array('current-menu-item', $classes) || in_array('current_page_item', $classes)) {
            $atts['class'] = 'current';
        }
        
        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);
        
        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }
        
        $title = apply_filters('the_title', $item->title, $item->ID);
        
        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;
        
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * Theme Customizer Settings
 */
function teslafolio_customize_register($wp_customize) {
    // Hero Section
    $wp_customize->add_section('teslafolio_hero', array(
        'title'    => __('Hero Section', 'teslafolio'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default'           => 'The Future of Innovation',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label'   => __('Hero Title', 'teslafolio'),
        'section' => 'teslafolio_hero',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('hero_subtitle', array(
        'default'           => 'Claim your exclusive BNB rewards',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label'   => __('Hero Subtitle', 'teslafolio'),
        'section' => 'teslafolio_hero',
        'type'    => 'textarea',
    ));
    
    $wp_customize->add_setting('hero_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hero_image', array(
        'label'   => __('Hero Background Image', 'teslafolio'),
        'section' => 'teslafolio_hero',
    )));
    
    // Contact Information
    $wp_customize->add_section('teslafolio_contact', array(
        'title'    => __('Contact Information', 'teslafolio'),
        'priority' => 40,
    ));
    
    $wp_customize->add_setting('whatsapp_number', array(
        'default'           => '+19453422063',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('whatsapp_number', array(
        'label'   => __('WhatsApp Number (with country code)', 'teslafolio'),
        'section' => 'teslafolio_contact',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('contact_email', array(
        'default'           => 'contact@teslafolio.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('contact_email', array(
        'label'   => __('Contact Email', 'teslafolio'),
        'section' => 'teslafolio_contact',
        'type'    => 'email',
    ));
    
    // Rewards Section
    $wp_customize->add_section('teslafolio_rewards', array(
        'title'    => __('Rewards Section', 'teslafolio'),
        'priority' => 50,
    ));
    
    $wp_customize->add_setting('rewards_amount', array(
        'default'           => '200,000',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('rewards_amount', array(
        'label'   => __('Rewards Amount (BNB)', 'teslafolio'),
        'section' => 'teslafolio_rewards',
        'type'    => 'text',
    ));
}
add_action('customize_register', 'teslafolio_customize_register');

/**
 * Helper function to get theme mod with default
 */
function teslafolio_get_option($key, $default = '') {
    return get_theme_mod($key, $default);
}

/**
 * Get WhatsApp link
 */
function teslafolio_whatsapp_link($message = '') {
    $number = preg_replace('/[^0-9]/', '', teslafolio_get_option('whatsapp_number', '+19453422063'));
    $url = 'https://wa.me/' . $number;
    if ($message) {
        $url .= '?text=' . urlencode($message);
    }
    return $url;
}

/**
 * Disable Gutenberg for a cleaner editing experience (optional)
 */
// add_filter('use_block_editor_for_post', '__return_false');
