<?php
/**
 * Template Name: Projects Page
 *
 * @package TeslaFolio
 */

get_header();
?>

<section class="hero" style="min-height: 50vh;">
    <div class="hero-bg">
        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%);"></div>
        <div class="hero-overlay"></div>
    </div>
    <div class="hero-content">
        <h1>Our <span class="text-red">Projects</span></h1>
        <p>Explore our portfolio of groundbreaking innovations and technologies.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="grid grid-3">
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-1.jpg" alt="Autonomous Fleet">
                </div>
                <div class="project-content">
                    <h3>Autonomous Fleet</h3>
                    <p>Next-generation self-driving technology powered by neural networks and real-time decision making. Our autonomous vehicles are setting new standards for safety and efficiency.</p>
                    <div class="project-tags">
                        <span class="project-tag">AI</span>
                        <span class="project-tag">Automation</span>
                        <span class="project-tag">Safety</span>
                    </div>
                </div>
            </div>
            
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-2.jpg" alt="Energy Grid">
                </div>
                <div class="project-content">
                    <h3>Energy Grid</h3>
                    <p>Revolutionary sustainable energy infrastructure connecting solar, battery, and grid systems worldwide. Powering millions of homes with clean, renewable energy.</p>
                    <div class="project-tags">
                        <span class="project-tag">Solar</span>
                        <span class="project-tag">Storage</span>
                        <span class="project-tag">Grid</span>
                    </div>
                </div>
            </div>
            
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-3.jpg" alt="Neural Interface">
                </div>
                <div class="project-content">
                    <h3>Neural Interface</h3>
                    <p>Brain-computer interface technology enabling seamless human-machine communication. Opening new possibilities for medical treatments and human enhancement.</p>
                    <div class="project-tags">
                        <span class="project-tag">Neurotech</span>
                        <span class="project-tag">BCI</span>
                        <span class="project-tag">Medical</span>
                    </div>
                </div>
            </div>
            
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-4.jpg" alt="Robotics Division">
                </div>
                <div class="project-content">
                    <h3>Robotics Division</h3>
                    <p>Humanoid robots designed to perform dangerous, repetitive, or boring tasks. Advancing the future of work and human-robot collaboration.</p>
                    <div class="project-tags">
                        <span class="project-tag">Robotics</span>
                        <span class="project-tag">AI</span>
                        <span class="project-tag">Automation</span>
                    </div>
                </div>
            </div>
            
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-5.jpg" alt="Satellite Network">
                </div>
                <div class="project-content">
                    <h3>Satellite Network</h3>
                    <p>Global satellite internet constellation providing high-speed connectivity to underserved areas. Bridging the digital divide worldwide.</p>
                    <div class="project-tags">
                        <span class="project-tag">Space</span>
                        <span class="project-tag">Internet</span>
                        <span class="project-tag">Global</span>
                    </div>
                </div>
            </div>
            
            <div class="project-card">
                <div class="project-image">
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/project-6.jpg" alt="Urban Transit">
                </div>
                <div class="project-content">
                    <h3>Urban Transit</h3>
                    <p>Underground transportation system eliminating traffic congestion in major cities. High-speed pods moving people efficiently beneath city streets.</p>
                    <div class="project-tags">
                        <span class="project-tag">Transit</span>
                        <span class="project-tag">Urban</span>
                        <span class="project-tag">Infrastructure</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section section-dark">
    <div class="container text-center">
        <h2>Interested in Our <span class="text-red">Work</span>?</h2>
        <p style="max-width: 600px; margin: 0 auto 2rem;">Join our community and be part of the technological revolution. Claim your exclusive BNB rewards today.</p>
        <a href="<?php echo esc_url(teslafolio_whatsapp_link("I'm interested in the Tesla Giveaway")); ?>" class="btn btn-red" target="_blank" rel="noopener noreferrer">
            Claim Your Reward
        </a>
    </div>
</section>

<?php get_footer(); ?>
