<?php
/**
 * Front Page Template
 * 
 * This template is used when a static front page is set in Settings > Reading
 *
 * @package TeslaFolio
 */

// Use the index.php template for the front page
get_template_part('index');
