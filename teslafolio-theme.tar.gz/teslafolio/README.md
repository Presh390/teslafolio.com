# TeslaFolio WordPress Theme

A Tesla-inspired minimalist dark theme for giveaway and rewards websites.

## Installation

1. Download the `teslafolio` folder
2. Upload it to your WordPress installation at `/wp-content/themes/`
3. Go to **Appearance > Themes** in your WordPress admin
4. Activate the **TeslaFolio** theme

## Setup Instructions

### 1. Create Pages

Create the following pages in WordPress:
- **Home** - Set as the front page
- **About** - Use "About Page" template
- **Projects** - Use "Projects Page" template
- **Contact** - Use "Contact Page" template

### 2. Set Up Navigation

1. Go to **Appearance > Menus**
2. Create a new menu called "Primary Menu"
3. Add your pages to the menu
4. Assign it to the "Primary Menu" location

### 3. Customize Your Site

1. Go to **Appearance > Customize**
2. Configure the following sections:
   - **Hero Section**: Set your hero title, subtitle, and background image
   - **Contact Information**: Set your WhatsApp number and email
   - **Rewards Section**: Set the BNB rewards amount

### 4. Add Images

Upload project images to:
- `/assets/images/project-1.jpg` through `project-6.jpg`
- `/assets/images/mission.jpg`
- `/assets/images/about-story.jpg`
- `/assets/images/vision.jpg`

Or upload them through the WordPress Media Library and use the Customizer.

## Theme Features

- Fully responsive dark mode design
- Tesla-inspired minimalist aesthetic
- WhatsApp integration for direct communication
- Customizer options for easy configuration
- SEO-friendly markup
- Smooth scroll navigation
- Animated elements on scroll
- Contact form with WhatsApp redirect

## Customization

### Colors

Edit the CSS variables in `style.css` to customize colors:

```css
:root {
    --tesla-red: #E82127;
    --tesla-dark: #121212;
    --tesla-darker: #0a0a0a;
    /* ... */
}
```

### Fonts

The theme uses:
- **Orbitron** - For headings
- **Inter** - For body text

These are loaded from Google Fonts.

## Support

For questions or support, contact via WhatsApp at the number configured in the theme settings.

## License

GNU General Public License v2 or later
